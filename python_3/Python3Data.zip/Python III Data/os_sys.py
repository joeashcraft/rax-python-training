"""
You may need to change the values of the
ds and di variables to get a meaningful result.
"""

import os, sys
ds = '/home/student/pydata/words.txt' #directory with file
di = '/home/student/pydata'    #directory only
# ds = 'c:/pydata/words.txt'
# di = 'c:/pydata'

print 'Did we get this far?'
