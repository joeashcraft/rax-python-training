"""
This program uses a comprehension to create a dictionary for testing.
"""

dc = {x: ord(x) - 96 for x in 'abcdef'}
print dc

