"""
This program demonstrates the use of integer division and printing
without benefit of the __future__ module'
"""

print 7/3
print 'Why wait for version 3?',
print 'Really!'

